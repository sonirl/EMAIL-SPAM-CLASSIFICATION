from flask import Flask,render_template,url_for,request
import pandas as pd
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import BernoulliNB
from sklearn.model_selection import train_test_split


# load the model from disk
file = 'modeltf.pkl'
naive_model = pickle.load(open(file, 'rb'))
tf_VEC=pickle.load(open('transform.pkl','rb'))

app = Flask(__name__)

@app.route('/')
def home():
	return render_template('home.html')

@app.route('/predict',methods=['POST'])
def predict():
	df1 = pd.read_csv("df1.csv")
	df1.dropna(inplace=True)
	tf_VEC = TfidfVectorizer(max_features=3000)
	X_tf = tf_VEC.fit_transform(df1['clean_message'])
	y = df1['label']

	pickle.dump(tf_VEC, open('transform.pkl', 'wb'))



	from sklearn.model_selection import train_test_split
	X_train_tf,X_test_tf,y_train_tf,y_test_tf = train_test_split(X_tf,y,test_size = 0.3, random_state=42)
	#Naive Bayes Classifier
	from sklearn.naive_bayes import BernoulliNB

	naive_model = BernoulliNB()
	naive_model.fit(X_train_tf,y_train_tf)
	naive_model.score(X_test_tf,y_test_tf)
	file = 'modeltf.pkl'
	pickle.dump(naive_model, open(file, 'wb'))


	#Alternative Usage of Saved Model
	# joblib.dump(clf, 'NB_spam_model.pkl')
	# NB_spam_model = open('NB_spam_model.pkl','rb')
	# clf = joblib.load(NB_spam_model)

	if request.method == 'POST':
		message = request.form['message']
		data = [message]
		vect = tf_VEC.transform(data).toarray()
		my_prediction = naive_model.predict(vect)
	return render_template('result.html',prediction = my_prediction)



if __name__ == '__main__':
	app.run(debug=True)